// Superadmin-only endpoint: POST /create-staff
// Body: { name, staffId, password, role }  (role: 'staff' | 'admin' | 'superadmin')
//
// Creates a real Supabase Auth user for the login (secure, hashed password
// storage — nothing plaintext ever touches the database) plus the
// `admins` profile doc the rest of the app already reads for
// name/staffId/role/active. The very first account is allowed to
// bootstrap with no caller session (so there's a way in on a brand new
// project); every call after that requires a signed-in superadmin.
import { supabaseAdmin, callerProfile, staffIdToEmail } from "../_shared/supabaseAdmin.ts";
import { corsHeaders, handleOptions, json } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  const preflight = handleOptions(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const admin = supabaseAdmin();
  const payload = await req.json().catch(() => null);
  if (!payload?.name || !payload?.staffId || !payload?.password) {
    return json({ error: "name, staffId and password are required" }, 400);
  }
  const role = ["staff", "admin", "superadmin"].includes(payload.role) ? payload.role : "staff";

  const { count } = await admin.from("admins").select("id", { count: "exact", head: true });
  const isBootstrap = (count || 0) === 0;

  if (!isBootstrap) {
    const caller = await callerProfile(req);
    if (!caller || caller.role !== "superadmin") {
      return json({ error: "Only a superadmin can create staff logins" }, 403);
    }
  }

  const email = staffIdToEmail(payload.staffId);
  const { data: created, error: createErr } = await admin.auth.admin.createUser({
    email,
    password: payload.password,
    email_confirm: true,
  });
  if (createErr) return json({ error: createErr.message }, 400);

  const now = new Date().toISOString();
  const adminDocId = crypto.randomUUID();
  const adminDoc = {
    name: payload.name,
    staffId: payload.staffId,
    role: isBootstrap ? "superadmin" : role,
    active: true,
    createdAt: now,
  };

  const { error: docErr } = await admin.from("admins").insert({ id: adminDocId, data: adminDoc });
  if (docErr) return json({ error: docErr.message }, 500);

  const { error: profileErr } = await admin.from("profiles").insert({
    user_id: created.user.id,
    staff_id: payload.staffId,
    admin_doc_id: adminDocId,
    role: adminDoc.role,
  });
  if (profileErr) return json({ error: profileErr.message }, 500);

  return json({ id: adminDocId, ...adminDoc, bootstrap: isBootstrap }, 200);
});
