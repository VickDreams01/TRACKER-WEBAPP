// Authenticated endpoint: POST /book-parcel
// Body: { sender, receiver, description, weightKg, serviceType, clientId?, sendNotification? }
//
// Replaces the frontend's old composeTrackingNotifications(), which only
// *composed* email/SMS text locally (a published Artifact page has no way
// to actually send anything). This function does the real work server
// side, where the Resend/Termii API keys live as secrets:
//   1. generates the tracking number and writes the parcel doc
//   2. if sendNotification is not explicitly false, sends a real email (if
//      an email was given) and/or real SMS (if a phone was given) to
//      sender and receiver — the booking form has two buttons ("Save
//      Parcel" vs "Save & Send Tracking ID") that map to this flag, so
//      staff can book without notifying yet and send later some other way
//   3. records what was sent (if anything) in the notifications
//      collection, exactly like the old client-side version did, so the
//      rest of the app (the booking-confirmation panel, the Admin detail
//      view) doesn't change
//
// Requires a logged-in staff session (booking has always been a staff-only
// action in this app — customers don't book their own parcels).
import { supabaseAdmin, callerProfile } from "../_shared/supabaseAdmin.ts";
import { sendEmail, sendSms } from "../_shared/notify.ts";
import { corsHeaders, handleOptions, json } from "../_shared/cors.ts";

function genTrackingNumber(prefix: string) {
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  const stamp = Date.now().toString(36).slice(-4).toUpperCase();
  return `${prefix}-${stamp}${rand}`.slice(0, 14);
}

Deno.serve(async (req) => {
  const preflight = handleOptions(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const caller = await callerProfile(req);
  if (!caller) return json({ error: "Not signed in" }, 401);

  const payload = await req.json().catch(() => null);
  if (!payload?.sender?.name || !payload?.receiver?.name) {
    return json({ error: "sender.name and receiver.name are required" }, 400);
  }

  const admin = supabaseAdmin();

  const { data: settingsRow } = await admin
    .from("settings")
    .select("data")
    .eq("id", "company")
    .maybeSingle();
  const settings = settingsRow?.data || { name: "STALLIONKING TRACKER", prefix: "STK" };

  let tn = genTrackingNumber(settings.prefix || "STK");
  // Vanishingly unlikely to collide, but make sure before we commit to it.
  for (let i = 0; i < 3; i++) {
    const { data: exists } = await admin.from("parcels").select("id").eq("id", tn).maybeSingle();
    if (!exists) break;
    tn = genTrackingNumber(settings.prefix || "STK");
  }

  const now = new Date().toISOString();
  const doc = {
    trackingNumber: tn,
    createdAt: now,
    updatedAt: now,
    sender: payload.sender,
    receiver: payload.receiver,
    senderClientId: payload.clientId || null,
    rebookedFrom: null,
    rebookedTo: null,
    description: payload.description || "",
    weightKg: payload.weightKg || "",
    serviceType: payload.serviceType || "Standard",
    status: "booked",
    rider: null,
    history: [
      {
        status: "booked",
        label: "Booked",
        timestamp: now,
        location: payload.sender.city ? `${payload.sender.city} Hub` : "",
        actor: caller.staff_id,
        note: "",
      },
    ],
  };

  const { error: insertErr } = await admin.from("parcels").insert({ id: tn, data: doc, created_at: now });
  if (insertErr) return json({ error: insertErr.message }, 500);

  // ---- real notifications (skipped entirely if the staff member chose
  // "Save Parcel" instead of "Save & Send Tracking ID") ----
  const wantsSend = payload.sendNotification !== false;
  const company = settings.name || "STALLIONKING TRACKER";
  const route = `${doc.sender.city || ""} → ${doc.receiver.city || ""}`;
  const contacts = [
    { role: "Sender", name: doc.sender.name, email: doc.sender.email, phone: doc.sender.phone },
    { role: "Receiver", name: doc.receiver.name, email: doc.receiver.email, phone: doc.receiver.phone },
  ];

  const notifications: Record<string, unknown>[] = [];
  if (wantsSend) {
    for (const c of contacts) {
      if (c.email) {
        const subject = `Your parcel is booked — Tracking No. ${tn}`;
        const body = `Hi ${c.name}, your parcel with ${company} has been booked. Tracking number: ${tn}. Route: ${route}. Track it anytime on our Track a Parcel page using this number. Thank you for shipping with us.`;
        const result = await sendEmail({ to: c.email, subject, body });
        notifications.push({
          channel: "email",
          recipientRole: c.role,
          to: c.email,
          sentAt: new Date().toISOString(),
          subject,
          body,
          delivered: result.ok,
          providerResponse: result.providerResponse,
        });
      }
      if (c.phone) {
        const body = `${company}: Your tracking No. is ${tn}. Track it anytime on our website using this number. Thank you!`;
        const result = await sendSms({ to: c.phone, body });
        notifications.push({
          channel: "sms",
          recipientRole: c.role,
          to: c.phone,
          sentAt: new Date().toISOString(),
          body,
          delivered: result.ok,
          providerResponse: result.providerResponse,
        });
      }
    }
  }

  // Stamp the sent notifications onto the parcel doc itself (Admin detail
  // view reads p.notifications) and log each one in the notifications
  // collection.
  doc.notifications = notifications;
  await admin.from("parcels").update({ data: doc }).eq("id", tn);

  for (const n of notifications) {
    await admin.from("notifications").insert({
      id: crypto.randomUUID(),
      data: {
        kind: "tracking_notification",
        trackingNumber: tn,
        ...n,
        createdAt: new Date().toISOString(),
        readBy: [],
      },
    });
  }

  await admin.from("activity_log").insert({
    id: crypto.randomUUID(),
    data: {
      type: "parcel_booked",
      summary: `Booked parcel ${tn} for ${doc.receiver.name}`,
      targetType: "parcel",
      targetId: tn,
      actor: caller.staff_id,
      createdAt: new Date().toISOString(),
    },
  });

  if (notifications.length) {
    await admin.from("activity_log").insert({
      id: crypto.randomUUID(),
      data: {
        type: "tracking_notified",
        summary: `Sent tracking ID ${tn} to ${notifications.length} recipient${notifications.length === 1 ? "" : "s"} by email/SMS`,
        targetType: "parcel",
        targetId: tn,
        actor: caller.staff_id,
        createdAt: new Date().toISOString(),
      },
    });
  }

  return json({ tn, notifications, notificationsSkipped: !wantsSend }, 200);
});
