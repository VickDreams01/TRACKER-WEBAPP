// Public endpoint: GET /track?tn=STK-XXXXXX
//
// The customer-facing "Track a Parcel" page never gets a Supabase Auth
// session, so it can't read the parcels table directly (RLS on `parcels`
// only grants access to `authenticated` staff — see migrations/0001_init.sql).
// Instead it calls this function, which looks the one parcel up with the
// service role key and returns just that document. No listing, no
// enumeration of other tracking numbers.
import { supabaseAdmin } from "../_shared/supabaseAdmin.ts";
import { corsHeaders, handleOptions, json } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  const preflight = handleOptions(req);
  if (preflight) return preflight;

  const url = new URL(req.url);
  const tn = (url.searchParams.get("tn") || "").trim().toUpperCase();
  if (!tn) return json({ error: "Missing tn (tracking number)" }, 400);

  const admin = supabaseAdmin();
  const { data, error } = await admin
    .from("parcels")
    .select("data")
    .eq("id", tn)
    .maybeSingle();

  if (error) return json({ error: error.message }, 500);
  if (!data) return json({ error: "not_found" }, 404);

  return json({ parcel: data.data }, 200);
});
