// Superadmin-only endpoint: POST /update-staff
// Body: { staffId, newPassword?, role?, active? }  (all of newPassword/role/active optional — send only what's changing)
//
// Handles everything about an existing staff login that touches either
// Supabase Auth (the password) or the profiles.role the edge functions and
// RLS policies rely on for server-side authorization — both of which the
// browser is deliberately not allowed to write directly (see
// admins_write_superadmin_only in the migration). Ordinary field edits
// (display name) can still go straight through the Supabase adapter from
// the frontend since they carry no privilege implications.
import { supabaseAdmin, callerProfile } from "../_shared/supabaseAdmin.ts";
import { corsHeaders, handleOptions, json } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  const preflight = handleOptions(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const caller = await callerProfile(req);
  if (!caller || caller.role !== "superadmin") {
    return json({ error: "Only a superadmin can update a staff login" }, 403);
  }

  const payload = await req.json().catch(() => null);
  if (!payload?.staffId) return json({ error: "staffId is required" }, 400);

  const admin = supabaseAdmin();
  const { data: profile, error: profileErr } = await admin
    .from("profiles")
    .select("user_id, admin_doc_id, role")
    .eq("staff_id", payload.staffId)
    .maybeSingle();
  if (profileErr) return json({ error: profileErr.message }, 500);
  if (!profile) return json({ error: "No login found for that Staff ID" }, 404);

  if (payload.role && !["staff", "admin", "superadmin"].includes(payload.role)) {
    return json({ error: "Invalid role" }, 400);
  }

  if (payload.newPassword) {
    const { error } = await admin.auth.admin.updateUserById(profile.user_id, {
      password: payload.newPassword,
    });
    if (error) return json({ error: error.message }, 400);
  }

  if (payload.role) {
    const { error } = await admin.from("profiles").update({ role: payload.role }).eq("user_id", profile.user_id);
    if (error) return json({ error: error.message }, 500);
  }

  if (payload.role || payload.active !== undefined) {
    const { data: row, error: getErr } = await admin
      .from("admins")
      .select("data")
      .eq("id", profile.admin_doc_id)
      .maybeSingle();
    if (getErr) return json({ error: getErr.message }, 500);
    const merged = Object.assign({}, row?.data || {});
    if (payload.role) merged.role = payload.role;
    if (payload.active !== undefined) merged.active = payload.active;
    const { error: updErr } = await admin.from("admins").update({ data: merged }).eq("id", profile.admin_doc_id);
    if (updErr) return json({ error: updErr.message }, 500);
  }

  return json({ ok: true }, 200);
});
