# Stallionking Tracker — real backend

This turns the STALLIONKING TRACKER demo into a real, production-backed
system: a Postgres database with real accounts (Supabase), and real
tracking-ID email/SMS sending (Resend + Termii) — instead of the
in-browser "shared preview" data and simulated notifications the Claude
Artifact version used.

**What you get**

- A real database (Supabase Postgres) — parcels, riders, clients, staff
  logins, notifications and the activity log all persist for real, with
  live updates pushed to every open tab (Realtime).
- Real staff logins (Supabase Auth) — passwords are hashed and stored
  properly, never in plain text like the demo version.
- Real tracking-ID emails and SMS, sent the moment a parcel is booked.
- The same app you've been using — same screens, same Staff ID + password
  login form, same workflows. Only how it stores and sends things changed.

**What it costs.** Supabase, Resend and Termii all have free tiers that
comfortably cover a small logistics operation getting started (a few
hundred to a few thousand parcels/messages a month, depending on the
provider — check their current pricing pages, since free-tier limits do
change). You'll only start paying if the business outgrows those limits.

---

## 1. Create the Supabase project

1. Go to [supabase.com](https://supabase.com), sign up, and create a new
   project (pick a region close to Nigeria if offered, e.g. an EU region).
2. In **Project Settings → API**, copy the **Project URL** and the
   **anon public** key — you'll paste both into the frontend in step 4.
   (Never copy the **service_role** key anywhere in the frontend — it's
   only used inside the edge functions, set as a secret in step 3.)
3. In **Project Settings → General**, note your **Project Reference ID**
   (you'll need it for the CLI in step 3).

## 2. Run the database migration

In the Supabase dashboard, open **SQL Editor**, paste the contents of
`supabase/migrations/0001_init.sql`, and run it. This creates every table,
the security rules (Row Level Security) that keep staff data away from
anonymous visitors, and turns on Realtime for live updates.

(If you'd rather use the CLI: `supabase link --project-ref <your-ref>`
then `supabase db push`.)

One extra manual step the SQL can't do for you: open **Database →
Replication** in the dashboard and confirm the tables listed in the
migration (settings, riders, clients, admins, parcels, notifications,
activity_log, deletion_requests) are enabled for Realtime — the migration
adds them to the publication, but newer Supabase projects also gate
Realtime behind an RLS-aware toggle worth double-checking there.

## 3. Deploy the edge functions

These handle the things that need to stay off the browser: sending real
email/SMS (needs the provider API keys, which must never reach client-side
code) and creating/managing staff logins (needs the service role key).

Install the [Supabase CLI](https://supabase.com/docs/guides/cli) if you
haven't already, then from the `stallionking-backend/` folder:

```bash
supabase login
supabase link --project-ref <your-project-ref>

# Secrets used by the functions — fill in your real values:
supabase secrets set RESEND_API_KEY=re_xxxxxxxx
supabase secrets set RESEND_FROM="Stallionking Tracker <tracking@yourdomain.com>"
supabase secrets set TERMII_API_KEY=xxxxxxxx
supabase secrets set TERMII_SENDER_ID=YourSenderID

supabase functions deploy track --no-verify-jwt
supabase functions deploy book-parcel
supabase functions deploy create-staff
supabase functions deploy update-staff
```

(`track` is the only one deployed with `--no-verify-jwt`, since it's the
public tracking-lookup endpoint customers hit with no login. The other
three check who's calling from inside the function itself.)

**Getting the provider accounts:**

- **Resend** (email) — sign up at [resend.com](https://resend.com), verify
  a sending domain (or use their shared test domain to start), create an
  API key. Free tier is generous for a small operation.
- **Termii** (SMS — reliable delivery to Nigerian numbers) — sign up at
  [termii.com](https://termii.com), register a Sender ID (approval usually
  takes a day or so), get your API key from the dashboard. If you'd rather
  use a different provider (Africa's Talking, Twilio, etc.), swap the body
  of `sendSms()` in `supabase/functions/_shared/notify.ts` — everything
  else calling it stays the same.

If these secrets aren't set yet, booking still works — the parcel is
created for real, the notification preview just won't actually deliver
(you'll see that noted in the booking-confirmation panel).

## 4. Point the frontend at your project

Open `frontend/parcel-tracker.html` and find, near the top of the main
`<script>` block:

```js
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
```

Replace both with the values from step 1. That's the only edit needed —
everything else (which edge function to call, table names, etc.) is
already wired up.

Until you fill these in, the page runs exactly like the old demo (a
"Backend not configured" banner, local-only sample data) — so it's safe to
open and click around before you've finished setup.

## 5. Host the page

`frontend/parcel-tracker.html` and `frontend/supabase-adapter.js` are a
plain static site — two files, no build step. Upload them together
(keeping them in the same folder, since the HTML loads the adapter by a
relative path) to any static host: Netlify, Vercel, GitHub Pages,
Cloudflare Pages, or your own web server. Keep using the Claude Artifact
version for demos if you like — this is a separate, independent copy.

## 6. First login

Open the hosted page and sign in with the seeded superadmin login:
**Staff ID `SK-0001`, password `admin123`.** Go to **Admin → Admin Users**
straight away and change that password (or create your own superadmin
login and deactivate this one) — everyone who ever saw this README knows
that default password.

Creating additional staff logins from then on works the same as before,
from the Admin Users screen — it's just backed by real accounts now.

---

## How it fits together

- **`supabase/migrations/0001_init.sql`** — the database schema. Every
  collection the app used to talk to (parcels, riders, clients, admins,
  notifications, activityLog, deletionRequests, settings) is a real table
  now, plus a `profiles` table linking real login accounts to staff roles.
- **`supabase/functions/`** — the four server-side actions that need
  secrets or elevated privilege: `track` (public tracking lookup),
  `book-parcel` (creates the parcel and sends the real notifications),
  `create-staff` / `update-staff` (manage logins without ever handling
  plaintext passwords in the database).
- **`frontend/supabase-adapter.js`** — a small compatibility layer that
  makes Supabase look like the Firestore-style API the app was already
  written against (`db.collection('x').doc(id).set(...)`, `.onSnapshot(...)`,
  etc.), so almost none of the original app code had to change.
- **`frontend/parcel-tracker.html`** — the same app, wired to call the
  above instead of the Claude Artifact's built-in shared-data capability.

## Security notes

- Only signed-in staff can read or write the operational tables
  (parcels, riders, clients, notifications, activity log). Customers get
  a single parcel's status through the public `track` function — never
  direct database access — so no one can browse the full parcel list
  without logging in.
- The `admins` table (the staff roster itself) is locked down further:
  any signed-in staff member can view it, but only a superadmin can
  create, edit, or deactivate a login — enforced both by a database rule
  and inside the edge functions, not just hidden in the UI. This closes a
  real gap the original demo had, where anyone with the shared preview
  link could technically see every staff member's plaintext password.
- A Staff ID can't be changed after a login is created (it's tied to the
  sign-in account). If one was mistyped, deactivate that login and create
  a fresh one.
- Passwords never touch the database directly — they're created and
  changed through Supabase Auth via the edge functions.

## Housekeeping

The database seeds a few sample riders, sample clients, and four fake
`STK-DEMO0001`–`STK-DEMO0004` parcels the first time it runs (handy for
trying the app immediately). Once you're taking real bookings, delete
those sample rows from the **Table Editor** in the Supabase dashboard —
they're just there to avoid an empty first-run screen.

## What wasn't rebuilt

Some things in the original demo depend on the Claude Artifact platform,
or would need decisions only you can make, and were left as-is rather than
guessed at:

- **Address/landmark autocomplete** still uses the built-in curated list
  of Nigerian streets, not a live maps API — swap it for one (Google
  Places, Mapbox, etc.) if you want live suggestions; that's a frontend-only
  change and doesn't touch this backend.
- **Fine-grained permissions** beyond staff/admin/superadmin (e.g.
  restricting who can approve a deletion request, or who can report a
  delivery exception) aren't enforced at the database level — the RLS
  hardening here focused on the one place that mattered most, the staff
  roster itself. The same pattern used for `admins` in the migration can
  extend to other tables if you want that later.
